package com.muslimmr.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("location", Context.MODE_PRIVATE)
        val lat = prefs.getFloat("lat", 32.88f).toDouble()
        val lon = prefs.getFloat("lon", -6.91f).toDouble()
        PrayerScheduler.schedule(context, lat, lon)

        val service = Intent(context, AdhanService::class.java)
        if (intent.getStringExtra("kind") == "adhan") {
            service.action = AdhanService.START
            service.putExtra("prayer", intent.getStringExtra("prayer") ?: "الصلاة")
        } else {
            service.action = AdhanService.SPEAK
            service.putExtra("kind", intent.getStringExtra("kind") ?: "evening")
            service.putExtra("prayer", intent.getStringExtra("prayer") ?: "")
        }
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service)
        else context.startService(service)
    }
}
