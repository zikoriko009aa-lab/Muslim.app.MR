package com.muslimmr.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.batoulapps.adhan.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val green = 0xFF064B2A.toInt()
    private val gold = 0xFFFFD45A.toInt()
    private lateinit var root: LinearLayout
    private var lat = 32.88
    private var lon = -6.91
    private val prayers = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannels()
        askPermissions()
        readLocation()
        PrayerScheduler.schedule(this, lat, lon)
        showHome()
    }

    private fun askPermissions() {
        val wanted = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            wanted.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (wanted.isNotEmpty()) ActivityCompat.requestPermissions(this, wanted.toTypedArray(), 41)
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            // The app still schedules inexact alarms if exact-alarm access is not granted.
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        readLocation()
        PrayerScheduler.schedule(this, lat, lon)
    }

    private fun readLocation() {
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            var best: Location? = null
            for (p in providers) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.accuracy < best!!.accuracy) best = l
            }
            if (best != null) {
                lat = best!!.latitude; lon = best!!.longitude
                getSharedPreferences("location", MODE_PRIVATE).edit().putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()
            }
        } catch (_: Exception) {}
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("adhan_channel", "الأذان", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "تنبيه الأذان عند دخول وقت الصلاة"
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            })
            nm.createNotificationChannel(NotificationChannel("general_channel", "تذكيرات الصلاة", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun text(s: String, size: Float, color: Int = 0xFF173A28.toInt(), bold: Boolean = false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); gravity=Gravity.CENTER; if(bold) setTypeface(null,1); setPadding(8,10,8,10) }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text=label; setTextColor(0xFFFFFFFF.toInt()); backgroundTintList=android.content.res.ColorStateList.valueOf(green)
        setOnClickListener { action() }
    }

    private fun shell(title: String) {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18); setBackgroundColor(0xFFF5F2E8.toInt()) }
        val header = TextView(this).apply { text=title; textSize=25f; setTextColor(gold); gravity=Gravity.CENTER; setPadding(12,22,12,22); setBackgroundColor(green); setTypeface(null,1) }
        root.addView(header)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun showHome() {
        shell("☾  MUSLIM MR")
        root.addView(text("رفيقك اليومي للعبادة",18,green,true))
        root.addView(text("مواقيت الصلاة اليوم",20,green,true))
        val times = getTimes()
        val names = listOf("الفجر","الشروق","الظهر","العصر","المغرب","العشاء")
        val dates = listOf(times.fajr,times.sunrise,times.dhuhr,times.asr,times.maghrib,times.isha)
        names.indices.forEach { i ->
            val row = TextView(this).apply {
                text = "${names[i]}     •     ${SimpleDateFormat("hh:mm a", Locale("ar")).format(dates[i])}"
                textSize=18f; setTextColor(green); setPadding(14,14,14,14)
                setBackgroundColor(if(i%2==0) 0xFFE8E1CD.toInt() else 0xFFFFFFFF.toInt())
            }
            root.addView(row)
        }
        root.addView(text("الموقع: ${String.format(Locale.US,"%.3f",lat)}, ${String.format(Locale.US,"%.3f",lon)}",12,0xFF666666.toInt()))
        root.addView(text("طريقة الحساب: رابطة العالم الإسلامي • قد تختلف الدقائق حسب الجهة المحلية",12,0xFF666666.toInt()))
        root.addView(button("إعادة تحديد الموقع وتحديث المواقيت") { readLocation(); PrayerScheduler.schedule(this,lat,lon); showHome() })
        root.addView(button("القرآن الكريم – 114 سورة") { startActivity(Intent(this, QuranActivity::class.java)) })
        root.addView(button("الأدعية والأذكار") { showDuas() })
        root.addView(button("اختبار صوت الأذان") { startService(Intent(this, AdhanService::class.java).setAction(AdhanService.START).putExtra("prayer","تجربة الأذان")) })
        root.addView(button("إعدادات الأذان") { showSettings() })
    }

    private fun getTimes(): PrayerTimes {
        val c = Coordinates(lat, lon)
        val cal = Calendar.getInstance()
        val date = DateComponents(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH))
        val params = CalculationMethod.MUSLIM_WORLD_LEAGUE.getParameters()
        params.madhab = Madhab.SHAFI
        return PrayerTimes(c, date, params)
    }

    private fun showQuran() {
        shell("القرآن الكريم")
        root.addView(text("سور قصيرة للقراءة",20,green,true))
        val items = listOf(
            "سورة الفاتحة" to "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
            "سورة الإخلاص" to "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ",
            "سورة الفلق" to "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ",
            "سورة الناس" to "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ"
        )
        items.forEach { (t,v) -> root.addView(text(t,19,green,true)); root.addView(text(v,21,0xFF222222.toInt())) }
        root.addView(button("رجوع") { showHome() })
    }

    private fun showDuas() {
        shell("الأدعية والأذكار")
        val duas = listOf(
            "قبل الصلاة" to "اللهم أعني على ذكرك وشكرك وحسن عبادتك. استعد للصلاة بالوضوء والسكينة.",
            "بعد الصلاة" to "أستغفر الله، أستغفر الله، أستغفر الله. اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام.",
            "ذكر بعد الصلاة" to "سبحان الله 33 مرة، والحمد لله 33 مرة، والله أكبر 33 مرة.",
            "دعاء" to "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.",
            "دعاء" to "اللهم أعني على ذكرك وشكرك وحسن عبادتك.",
            "الصباح والمساء" to "رضيت بالله رباً، وبالإسلام ديناً، وبمحمد ﷺ نبياً.",
            "أذكار النوم" to "باسمك اللهم أموت وأحيا. اللهم قني عذابك يوم تبعث عبادك."
        )
        duas.forEach { (t,v) -> root.addView(text(t,19,green,true)); root.addView(text(v,20)) }
        root.addView(button("رجوع") { showHome() })
    }

    private fun showSettings() {
        shell("إعدادات الأذان")
        root.addView(text("الأذان يعمل بصوت الملف المرفق حتى إيقافه. التذكيرات الصوتية للأذكار تُقرأ بصوت عربي عبر محرك تحويل النص إلى كلام في هاتفك، وقد تحتاج إلى تثبيت بيانات الصوت العربي.",17))
        root.addView(button("إيقاف الأذان الآن") { stopService(Intent(this, AdhanService::class.java)); Toast.makeText(this,"تم إرسال أمر إيقاف الأذان",Toast.LENGTH_SHORT).show() })
        root.addView(button("فتح إعدادات الموقع") { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) })
        root.addView(button("رجوع") { showHome() })
    }
}
