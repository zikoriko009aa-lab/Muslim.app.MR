package com.muslimmr.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charset
import kotlin.concurrent.thread

class QuranActivity : Activity() {
    private val ivory = 0xFFFFFBF0.toInt()
    private val ink = 0xFF28221D.toInt()
    private val ornament = 0xFF9A8060.toInt()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private var chapters = mutableListOf<Chapter>()
    private var currentChapter: Chapter? = null

    data class Chapter(val id: Int, val name: String, val verses: Int, val place: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showShell()
        loadChapters()
    }

    private fun showShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ivory)
            setPadding(14, 12, 14, 12)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = TextView(this).apply {
            text = "‹"; textSize = 34f; setTextColor(ink); setPadding(8, 0, 18, 0)
            setOnClickListener { if (currentChapter != null) showChapterList() else finish() }
        }
        val title = TextView(this).apply {
            text = "القرآن الكريم"; textSize = 24f; setTextColor(ink)
            typeface = Typeface.DEFAULT_BOLD
        }
        top.addView(back)
        top.addView(title)
        root.addView(top)

        status = TextView(this).apply {
            text = "جاري تحميل فهرس السور..."; textSize = 14f
            setTextColor(ornament); gravity = Gravity.CENTER; setPadding(8, 8, 8, 8)
        }
        root.addView(status)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(2, 8, 2, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(text: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(8, 9, 8, 9)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(text: String, click: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 13, 12, 13)
            setBackgroundColor(0xFF17613C.toInt())
            setOnClickListener { click() }
        }

    private fun request(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection)
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.setRequestProperty("User-Agent", "MUSLIM-MR-Android")
        try {
            return connection.inputStream.bufferedReader(Charset.forName("UTF-8")).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun loadChapters() {
        thread {
            try {
                val json = JSONObject(request("https://api.quran.com/api/v4/chapters?language=ar"))
                val arr = json.getJSONArray("chapters")
                val found = mutableListOf<Chapter>()
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    found.add(
                        Chapter(
                            item.getInt("id"),
                            item.optString("name_arabic", item.optString("name_simple")),
                            item.optInt("verses_count", 0),
                            item.optString("revelation_place", "")
                        )
                    )
                }
                runOnUiThread {
                    chapters = found
                    showChapterList()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "تعذر الاتصال. تحقق من الإنترنت ثم أعد المحاولة."
                    content.removeAllViews()
                    content.addView(button("إعادة المحاولة") { loadChapters() })
                    loadCachedChaptersFallback()
                }
            }
        }
    }

    private fun loadCachedChaptersFallback() {
        // Arabic chapter names are included as a fallback so the reader remains navigable.
        val names = listOf(
            "الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس",
            "هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج",
            "المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب",
            "سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف",
            "محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة",
            "الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة",
            "المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس",
            "التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد",
            "الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة",
            "التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص",
            "الفلق","الناس"
        )
        chapters = names.mapIndexed { index, name -> Chapter(index + 1, "سورة $name", 0, "") }.toMutableList()
        showChapterList()
    }

    private fun showChapterList() {
        currentChapter = null
        content.removeAllViews()
        status.text = "114 سورة • اضغط على اسم السورة لفتحها"
        val download = button("تنزيل القرآن كاملاً للاستخدام دون إنترنت") { downloadAll() }
        content.addView(download)
        val search = EditText(this).apply {
            hint = "ابحث عن سورة..."
            textSize = 16f
            setSingleLine(true)
            gravity = Gravity.RIGHT
        }
        content.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        fun populate(filter: String = "") {
            list.removeAllViews()
            chapters.filter { it.name.contains(filter.trim(), true) || it.id.toString() == filter.trim() }
                .forEach { chapter ->
                    val item = TextView(this).apply {
                        text = "${chapter.id}.  ${chapter.name}     •     ${if (chapter.verses > 0) chapter.verses else "افتح"} آية"
                        textSize = 18f
                        setTextColor(ink)
                        gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                        setPadding(16, 15, 16, 15)
                        setBackgroundColor(if (chapter.id % 2 == 0) 0xFFF0E8D9.toInt() else ivory)
                        setOnClickListener { openChapter(chapter) }
                    }
                    list.addView(item)
                }
        }
        populate()
        search.addTextChangedListener(SimpleTextWatcher { populate(it) })
    }

    private fun cacheFile(id: Int) = File(filesDir, "quran_surah_$id.json")

    private fun openChapter(chapter: Chapter) {
        currentChapter = chapter
        content.removeAllViews()
        status.text = "سورة ${chapter.name.removePrefix("سورة ")}"
        val cached = cacheFile(chapter.id)
        if (cached.exists()) {
            try {
                displayVerses(chapter, JSONObject(cached.readText()))
                return
            } catch (_: Exception) { cached.delete() }
        }
        content.addView(label("جاري تحميل السورة بالرسم العثماني...", 18f, ornament))
        thread {
            try {
                val url = "https://api.quran.com/api/v4/quran/verses/uthmani?chapter_number=${chapter.id}"
                val result = request(url)
                cacheFile(chapter.id).writeText(result, Charsets.UTF_8)
                val json = JSONObject(result)
                runOnUiThread { displayVerses(chapter, json) }
            } catch (e: Exception) {
                runOnUiThread {
                    content.removeAllViews()
                    content.addView(label("تعذر تحميل السورة. تحقق من الإنترنت.", 18f))
                    content.addView(button("إعادة المحاولة") { openChapter(chapter) })
                    content.addView(button("العودة إلى فهرس السور") { showChapterList() })
                }
            }
        }
    }

    private fun displayVerses(chapter: Chapter, json: JSONObject) {
        currentChapter = chapter
        content.removeAllViews()
        status.text = "سورة ${chapter.name.removePrefix("سورة ")}"
        val banner = TextView(this).apply {
            text = "۞  ۞  ۞     سُورَةُ ${chapter.name.removePrefix("سورة ")}     ۞  ۞  ۞"
            textSize = 25f
            setTextColor(0xFF493A2A.toInt())
            gravity = Gravity.CENTER
            setPadding(10, 22, 10, 22)
            setBackgroundColor(0xFFEDE2CD.toInt())
            typeface = Typeface.create("serif", Typeface.BOLD)
        }
        content.addView(banner)
        content.addView(label("الرسم العثماني • رواية حفص عن عاصم", 12f, ornament))
        if (chapter.id != 1 && chapter.id != 9) {
            content.addView(label("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", 26f))
        }
        val verses = json.getJSONArray("verses")
        val text = StringBuilder()
        for (i in 0 until verses.length()) {
            val verse = verses.getJSONObject(i)
            val key = verse.optString("verse_key")
            val number = key.substringAfter(":").toIntOrNull() ?: (i + 1)
            val ayah = verse.optString("text_uthmani")
            text.append(ayah).append("  ﴿").append(number.toString().mapDigits()).append("﴾  ")
        }
        val body = TextView(this).apply {
            this.text = text.toString()
            textSize = 28f
            setTextColor(0xFF17130F.toInt())
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_RTL
            setLineSpacing(18f, 1.15f)
            setPadding(12, 28, 12, 34)
            typeface = Typeface.create("serif", Typeface.NORMAL)
        }
        content.addView(body)
        content.addView(label("صدق الله العظيم", 20f, ornament, true))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        if (chapter.id > 1) nav.addView(button("السورة السابقة") { openChapter(chapters.first { it.id == chapter.id - 1 }) }, LinearLayout.LayoutParams(0, -2, 1f))
        if (chapter.id < 114) nav.addView(button("السورة التالية") { openChapter(chapters.first { it.id == chapter.id + 1 }) }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(nav)
        content.addView(button("فهرس السور") { showChapterList() })
        content.addView(label("مصدر النص: Quran.com API • الرسم العثماني", 11f, ornament))
    }

    private fun downloadAll() {
        status.text = "جاري تنزيل القرآن كاملاً... لا تغلق التطبيق"
        content.removeAllViews()
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 114
            progress = 0
        }
        content.addView(progress)
        val message = label("سيتم حفظ السور على هاتفك لقراءتها دون إنترنت.", 16f)
        content.addView(message)
        thread {
            var done = 0
            var errors = 0
            for (id in 1..114) {
                try {
                    if (!cacheFile(id).exists()) {
                        val result = request("https://api.quran.com/api/v4/quran/verses/uthmani?chapter_number=$id")
                        cacheFile(id).writeText(result, Charsets.UTF_8)
                    }
                } catch (_: Exception) { errors++ }
                done++
                val completed = done
                runOnUiThread {
                    progress.progress = completed
                    message.text = "تم تجهيز $completed من 114 سورة"
                    status.text = "تنزيل القرآن: $completed / 114"
                }
            }
            runOnUiThread {
                message.text = if (errors == 0) "اكتمل تنزيل السور الـ114. يمكنك الآن القراءة دون إنترنت."
                else "اكتمل التنزيل مع $errors أخطاء. أعد المحاولة لتحميل السور الناقصة."
                content.addView(button("العودة إلى السور") { showChapterList() })
            }
        }
    }

    private fun String.mapDigits(): String {
        val digits = "٠١٢٣٤٥٦٧٨٩"
        return map { if (it in '0'..'9') digits[it - '0'] else it }
    }
}

private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
