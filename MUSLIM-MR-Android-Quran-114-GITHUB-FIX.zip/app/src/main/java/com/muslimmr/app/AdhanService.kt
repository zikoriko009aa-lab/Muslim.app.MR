package com.muslimmr.app

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.util.Locale

class AdhanService : Service() {
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var quiet = false
    private var prayerName = "الصلاة"
    private var reminderMode = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            STOP -> { stopAll(); return START_NOT_STICKY }
            LOWER -> {
                quiet = !quiet
                player?.setVolume(if (quiet) 0.18f else 1f, if (quiet) 0.18f else 1f)
                updateNotification()
                return START_STICKY
            }
            SPEAK -> {
                reminderMode = true
                val kind = intent.getStringExtra("kind") ?: "evening"
                prayerName = intent.getStringExtra("prayer") ?: ""
                startForeground(78, buildReminderNotification(kind, prayerName))
                speakReminder(kind, prayerName)
                return START_NOT_STICKY
            }
            else -> {
                reminderMode = false
                prayerName = intent?.getStringExtra("prayer") ?: "الصلاة"
                startForeground(77, buildAdhanNotification())
                if (player == null) startAdhanAudio()
            }
        }
        return START_STICKY
    }

    private fun startAdhanAudio() {
        try {
            player = MediaPlayer.create(this, R.raw.adhan)
            player?.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            player?.isLooping = true
            player?.setVolume(if (quiet) 0.18f else 1f, if (quiet) 0.18f else 1f)
            player?.start()
        } catch (_: Exception) { stopAll() }
    }

    private fun reminderText(kind: String, prayer: String): String = when (kind) {
        "before" -> "اقترب موعد صلاة $prayer. استعد للصلاة، وتوضأ، وأكثر من ذكر الله. اللهم أعنا على ذكرك وشكرك وحسن عبادتك."
        "after" -> "لا تنس أذكار الصلاة. أستغفر الله، أستغفر الله، أستغفر الله. اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام. سبحان الله، والحمد لله، والله أكبر."
        "sleep" -> "حان وقت النوم. باسمك اللهم أموت وأحيا. اللهم قني عذابك يوم تبعث عبادك. اقرأ آية الكرسي وسور الإخلاص والفلق والناس."
        else -> "حافظ على أذكار المساء. أمسينا وأمسى الملك لله، والحمد لله. اللهم بك أمسينا وبك أصبحنا وبك نحيا وبك نموت وإليك المصير."
    }

    private fun speakReminder(kind: String, prayer: String) {
        val message = reminderText(kind, prayer)
        try {
            tts?.shutdown()
            tts = TextToSpeech(applicationContext) { status ->
                val engine = tts ?: return@TextToSpeech
                if (status == TextToSpeech.SUCCESS) {
                    val result = engine.setLanguage(Locale("ar"))
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.setLanguage(Locale.getDefault())
                    }
                    engine.setSpeechRate(0.88f)
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { stopSelf() }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { stopSelf() }
                    })
                    engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, "muslim-mr-reminder")
                } else stopSelf()
            }
        } catch (_: Exception) { stopSelf() }
    }

    private fun actionIntent(action: String, request: Int): PendingIntent {
        val i = Intent(this, AdhanService::class.java).setAction(action)
        return PendingIntent.getService(this, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun buildAdhanNotification(): Notification =
        NotificationCompat.Builder(this, "adhan_channel")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("حان وقت صلاة $prayerName")
            .setContentText("الأذان يعمل الآن — يمكنك خفض الصوت أو إيقافه")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .addAction(0, if (quiet) "رفع الصوت" else "خفض الصوت", actionIntent(LOWER, 2))
            .addAction(0, "إيقاف الأذان", actionIntent(STOP, 3))
            .build()

    private fun buildReminderNotification(kind: String, prayer: String): Notification {
        val title = when (kind) {
            "before" -> "اقترب موعد صلاة $prayer"
            "after" -> "أذكار بعد صلاة $prayer"
            "sleep" -> "أذكار النوم"
            else -> "أذكار المساء"
        }
        return NotificationCompat.Builder(this, "general_channel")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText("يتم الآن قراءة الذكر بصوت عربي")
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .addAction(0, "إيقاف الصوت", actionIntent(STOP, 4))
            .build()
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(77, buildAdhanNotification())
    }

    private fun stopAll() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
        tts?.stop(); tts?.shutdown(); tts = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        player?.release(); player = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }

    companion object {
        const val START = "com.muslimmr.START_ADHAN"
        const val STOP = "com.muslimmr.STOP_ADHAN"
        const val LOWER = "com.muslimmr.LOWER_ADHAN"
        const val SPEAK = "com.muslimmr.SPEAK_REMINDER"
    }
}
