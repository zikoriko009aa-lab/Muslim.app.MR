package com.muslimmr.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("location", Context.MODE_PRIVATE)
        val lat = prefs.getFloat("lat", 32.88f).toDouble()
        val lon = prefs.getFloat("lon", -6.91f).toDouble()
        PrayerScheduler.schedule(context, lat, lon)
    }
}
