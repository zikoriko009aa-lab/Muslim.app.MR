# MUSLIM MR — Android project

## Build APK with GitHub Actions
1. Upload the **contents** of this project to a GitHub repository (keep the folders and paths).
2. Open **Actions** → **Build MUSLIM MR APK** → **Run workflow**.
3. When it finishes, open the workflow run and download the `MUSLIM-MR-APK` artifact.
4. Extract the artifact ZIP to get `app-debug.apk`.

## Features
- Prayer-time calculations using the device's last known location (fallback: Khouribga coordinates).
- Five daily prayer alarms.
- Attached adhan MP3 loops until the user taps stop; notification offers lower/raise volume and stop.
- Quran short surahs and daily duas.
- Re-scheduling after reboot or app update.

## Important Android behavior
- Grant location and notification permissions.
- For reliable exact-time alarms on Android 12+, allow **Alarms & reminders** for MUSLIM MR in Android settings.
- Some Android manufacturers aggressively restrict background apps; exclude MUSLIM MR from battery optimization if alarms are delayed.
- The app uses Muslim World League prayer calculation with Shafi'i Asr. Local mosque timetables may differ by a few minutes. Confirm the calculation method and offsets for your locality.
- This is an initial project build; test alarms on the target phone before relying on it for prayer reminders.


## Full Quran reader
- Added a Quran reader with the complete index of 114 surahs and Uthmani Arabic verses.
- Surah pages use an ivory parchment-style background, ornamental surah heading, large Arabic script, and decorative ayah-number markers to echo the supplied reference image.
- Each surah is fetched from the Quran.com Content API and cached locally. The index and a surah's first reading require internet; use "تنزيل القرآن كاملاً للاستخدام دون إنترنت" inside the Quran section to cache all 114 surahs for offline reading.
- Source: Quran.com API, Uthmani script (`https://api.quran.com/api/v4/quran/verses/uthmani`). API documentation: https://api-docs.quran.com/docs/content_apis_versioned/4.0.0/quran-verses-by-script/
- The Quran text is displayed as returned by the source and must not be altered.
