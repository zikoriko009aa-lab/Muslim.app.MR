package com.muslimmr.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.*

object PrayerScheduler {
    private fun setAlarm(am: AlarmManager, context: Context, id: Int, time: Long, extras: Intent) {
        if (time <= System.currentTimeMillis()) return
        val pi = PendingIntent.getBroadcast(
            context, id, extras,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            else
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
        } else am.setExact(AlarmManager.RTC_WAKEUP, time, pi)
    }

    fun schedule(context: Context, lat: Double, lon: Double) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val params = com.batoulapps.adhan.CalculationMethod.MUSLIM_WORLD_LEAGUE.getParameters()
        params.madhab = com.batoulapps.adhan.Madhab.SHAFI
        val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

        for (day in 0..2) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, day) }
            val date = com.batoulapps.adhan.DateComponents(
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
            )
            val times = com.batoulapps.adhan.PrayerTimes(
                com.batoulapps.adhan.Coordinates(lat, lon), date, params
            )
            val prayerDates = listOf(times.fajr, times.dhuhr, times.asr, times.maghrib, times.isha)

            prayerDates.forEachIndexed { i, prayerDate ->
                val before = Intent(context, PrayerAlarmReceiver::class.java)
                    .setAction("com.muslimmr.REMINDER")
                    .putExtra("kind", "before")
                    .putExtra("prayer", names[i])
                setAlarm(am, context, 1000 + day * 100 + i * 2, prayerDate.time - 5 * 60_000L, before)

                val adhan = Intent(context, PrayerAlarmReceiver::class.java)
                    .setAction("com.muslimmr.ADHAN")
                    .putExtra("kind", "adhan")
                    .putExtra("prayer", names[i])
                setAlarm(am, context, 2000 + day * 100 + i, prayerDate.time, adhan)

                val after = Intent(context, PrayerAlarmReceiver::class.java)
                    .setAction("com.muslimmr.REMINDER")
                    .putExtra("kind", "after")
                    .putExtra("prayer", names[i])
                setAlarm(am, context, 3000 + day * 100 + i, prayerDate.time + 5 * 60_000L, after)
            }

            val evening = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, day)
                set(Calendar.HOUR_OF_DAY, 22); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val night = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, day)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val eveningIntent = Intent(context, PrayerAlarmReceiver::class.java)
                .setAction("com.muslimmr.REMINDER").putExtra("kind", "evening")
            val nightIntent = Intent(context, PrayerAlarmReceiver::class.java)
                .setAction("com.muslimmr.REMINDER").putExtra("kind", "sleep")
            setAlarm(am, context, 4000 + day, evening.timeInMillis, eveningIntent)
            setAlarm(am, context, 5000 + day, night.timeInMillis, nightIntent)
        }
    }
}
